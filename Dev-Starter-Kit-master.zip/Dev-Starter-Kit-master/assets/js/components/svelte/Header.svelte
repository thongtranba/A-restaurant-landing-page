
<style>
  header{
    background: #676778;
    color: red;
    text-align: center;
    padding: 20px;
    font-size: 1.1rem;
    font-weight: 700;
    color: white;
    }
</style>

<header id="header">
  Svelte Setup
</header>
